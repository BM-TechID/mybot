const fs = require('fs');
const crypto = require('crypto');
const axios = require('axios');

function getHarga(UsernameDF, APIkeyDF, persen) {
  let code = "pricelist";

  let hasho = crypto
    .createHash("md5")
    .update(global.UsernameDF + global.APIkeyDF + code)
    .digest("hex");

  var config = {
    method: "POST",
    url: `https://${global.digiFlazz}/v1/price-list`,
    data: {
      cmd: "prepaid",
      username: global.UsernameDF,
      sign: hasho,
    },
  };

  axios(config)
    .then(function (response) {
      let data = JSON.stringify(response.data.data, null, 2);
      fs.writeFileSync("./SETTING/DB/AdminPrepaid.json", data);
      console.log("API request successful.");
    })
    .catch((error) => {
      console.error("Error during API request:", error);
    });
}
module.exports = { getHarga }
function scheduleGetHarga() {
  // Menjadwalkan pemanggilan getHarga setiap 3 menit
  setInterval(() => {
    // Menunda pemanggilan getHarga selama 10 detik
    setTimeout(() => {
      getHarga(global.UsernameDF, global.APIkeyDF);
    }, 10000); // Penundaan 10 detik
  }, 180000); // 180000 milidetik = 3 menit
}

// Mulai penjadwalan
scheduleGetHarga();