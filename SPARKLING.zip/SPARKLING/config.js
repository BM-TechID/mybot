/**
   * Create By Nova-Ardian 
   * Contact Me on wa.me/6281244286074
   * Address me Bali, Gianyar, Sukawati 
**/

const fs = require('fs')


/*========= [ SET UP AWALAN ] ==========*/
global.owner = ['6281244286074']
global.premium = ['6281244286074']
global.syarat = ['6281244286074']
global.botNumber = '6282196900766'
global.ownerNomor = '6281244286074'
global.botname = 'SPARKLING BOTZ' 
global.ownername = 'NOVA-ARDIAN' 
global.footer = 'SPARKLING'
global.packname = `SPARKLING` 
global.toko = `PT SPARKLING DIGITAL`
global.sessionName = 'session'

/*======== [ SET UP DISKON PREMIUM ] ==========*/
global.Diskon = "000.0028" * 1

/*======== [ SET UP LAINNYA ] ==========*/
global.prefa = ['','!','.','🐦','🐤','🗿']
global.grup = `https://chat.whatsapp.com/DwVxacM5tc55VOXdA80lp4`
global.apiNick = 'api-rekening.lfourr.com'
global.digiFlazz = 'api.digiflazz.com'
global.APIcek = "cekid.tokogar.com"

/*======== [ SET UP WAKTU DEAFULT ] ==========*/
global.Wilayah = "Makassar" /*=> Makassar = WITA / => Jakarta = WIB / Jayapura = WIT */

/*======== [ SET UP SMTP EMAIL ] ==========*/
global.emailNotif = "sparklingofc@gmail.com"
global.pwNotif = "wuuwzdkxjawhblws"
/*======== [ SELAMAT MENGGUNAKAN ] ========*/

global.mess = {
wait: 'Nunggu bentar ya, lagi Loading...',
succes: 'Yes, Berhasil!',
admin: 'Oops, Hanya Admin Grup yang Boleh',
botAdmin: 'Waduh, Botnya Belum Jadi Admin',
owner: 'Maaf, Cuma Developer yang Bisa',
group: 'Aduh, Fitur Ini Khusus untuk Grup',
private: 'Maaf, Fitur Ini Hanya untuk Obrolan Pribadi',
bot: 'Aduh, Fitur Ini Hanya untuk Pengguna Bot!',
error: 'Ups, Ada Kesalahan...',
text: 'Hmm, Teksnya Kok Ga Ada Ya?'
}


